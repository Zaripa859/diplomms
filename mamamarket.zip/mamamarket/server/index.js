// МамаМаркет — Backend (Node.js + Express + SQLite)
const express = require('express');
const cors = require('cors');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;

// Деректер базасы (SQLite)
const db = new Database(path.join(__dirname, 'mamamarket.db'));
db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    description TEXT,
    image TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    product_id INTEGER,
    quantity INTEGER DEFAULT 1,
    total REAL,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
  );
`);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// ===== API маршруттары =====

// Өнімдер
app.get('/api/products', (req, res) => {
  const rows = db.prepare('SELECT * FROM products ORDER BY id DESC').all();
  res.json(rows);
});

app.post('/api/products', (req, res) => {
  const { name, price, description, image } = req.body;
  const info = db.prepare(
    'INSERT INTO products (name, price, description, image) VALUES (?, ?, ?, ?)'
  ).run(name, price, description, image);
  res.json({ id: info.lastInsertRowid });
});

app.delete('/api/products/:id', (req, res) => {
  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// Қолданушылар (тіркелу/кіру)
app.post('/api/register', (req, res) => {
  const { name, email, password } = req.body;
  try {
    const info = db.prepare(
      'INSERT INTO users (name, email, password) VALUES (?, ?, ?)'
    ).run(name, email, password);
    res.json({ id: info.lastInsertRowid, name, email });
  } catch (e) {
    res.status(400).json({ error: 'Email тіркелген немесе деректер дұрыс емес' });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare(
    'SELECT id, name, email FROM users WHERE email = ? AND password = ?'
  ).get(email, password);
  if (!user) return res.status(401).json({ error: 'Қате email немесе құпиясөз' });
  res.json(user);
});

// Тапсырыстар
app.get('/api/orders', (req, res) => {
  const rows = db.prepare(`
    SELECT o.*, p.name AS product_name, u.name AS user_name
    FROM orders o
    LEFT JOIN products p ON p.id = o.product_id
    LEFT JOIN users u ON u.id = o.user_id
    ORDER BY o.id DESC
  `).all();
  res.json(rows);
});

app.post('/api/orders', (req, res) => {
  const { user_id, product_id, quantity } = req.body;
  const product = db.prepare('SELECT price FROM products WHERE id = ?').get(product_id);
  const total = (product?.price || 0) * (quantity || 1);
  const info = db.prepare(
    'INSERT INTO orders (user_id, product_id, quantity, total) VALUES (?, ?, ?, ?)'
  ).run(user_id, product_id, quantity || 1, total);
  res.json({ id: info.lastInsertRowid, total });
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`✅ МамаМаркет сервері: http://localhost:${PORT}`);
});
