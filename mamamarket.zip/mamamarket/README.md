# МамаМаркет

Толық стек жоба:

- **Frontend:** HTML5, CSS3 (Tailwind CSS CDN), JavaScript — `public/index.html`
- **Backend:** Node.js + Express — `server/index.js`
- **Деректер базасы:** SQLite (better-sqlite3) — `server/mamamarket.db` (автоматты түрде жасалады)

## Іске қосу

```bash
npm install
npm start
```

Сосын браузерде аш: http://localhost:3000

## API маршруттары

| Әдіс | URL | Сипаттамасы |
|------|-----|-------------|
| GET | `/api/products` | Барлық өнімдер |
| POST | `/api/products` | Жаңа өнім қосу |
| DELETE | `/api/products/:id` | Өнімді жою |
| POST | `/api/register` | Тіркелу |
| POST | `/api/login` | Кіру |
| GET | `/api/orders` | Тапсырыстар тізімі |
| POST | `/api/orders` | Тапсырыс жасау |

## Құрылым

```
mamamarket/
├── package.json
├── README.md
├── public/
│   └── index.html      ← Frontend (өзгертілмеген)
└── server/
    ├── index.js        ← Express сервері
    └── mamamarket.db   ← SQLite базасы (авто)
```
